"""L5 四个工具在真实场景上的冒烟 —— 零 GPU。用完可删。"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scene_graph.store import load_scene  # noqa: E402
from tools import load_tools  # noqa: E402
from tools.registry import ToolContext  # noqa: E402
from tools.scene_report import counterfactual, describe_scene, diagnose_failure, summarize_scene  # noqa: E402

load_tools()

scene = load_scene(ROOT / "dataset" / "scenes" / "living_room_gt")
print("场景:", scene.summary_line())
print("build_meta 键:", sorted(scene.build_meta)[:14])
print()

ctx = ToolContext(scene=scene)

# ---- describe_scene -------------------------------------------------------
r = describe_scene(ctx, detail="brief")
print("[describe_scene detail=brief] ok =", r.ok, " latency =", round(r.meta.latency_ms, 1), "ms")
v = r.value
print("  objects:", len(v["objects"]), " quality:", v["quality"])
print("  relation_summary.n_pairs:", v["relation_summary"]["n_pairs"])
print("  caveats:")
for c in v["caveats"]:
    print("    -", c[:110])
print("  最近邻（前 3）:")
nn = v["relation_summary"]["nearest_neighbour"]
for oid, d in sorted(nn.items(), key=lambda kv: kv[1]["distance_m"])[:3]:
    print(f"    {oid} → {d['object_id']}  {d['distance_m']:.3f} m")

r_full = describe_scene(ctx, detail="full")
print()
print("[describe_scene detail=full] ok =", r_full.ok, " relations =", len(r_full.value["relations"]))
print("  头 3 条:", json.dumps(r_full.value["relations"][:3], ensure_ascii=False))

# ---- summarize_scene ------------------------------------------------------
print()
s = summarize_scene(ctx)
print("[summarize_scene 模板] ok =", s.ok, " deterministic =", s.evidence["deterministic"])
print(s.value)

s2 = summarize_scene(ctx, use_llm=True)
print()
print("[summarize_scene use_llm=True 未注入] ok =", s2.ok, " code =", s2.error.code.value)
print("  recovery:", [x.value for x in s2.error.recovery])
print("  hint:", s2.error.context.get("hint", "")[:100])

# ---- diagnose_failure -----------------------------------------------------
print()
d = diagnose_failure(ctx, question_id="q001")
print("[diagnose_failure] ok =", d.ok, " stage =", d.value["stage"])
for f in d.value["findings"]:
    print(f"  [{f['severity']:>4}] {f['stage']}: {f['reason'][:78]}")

# ---- counterfactual -------------------------------------------------------
print()
cf = counterfactual(ctx, remove=["sofa_1"])
print("[counterfactual remove=sofa_1] ok =", cf.ok)
diff = cf.value["diff"]
print("  物体数:", cf.evidence["n_objects_before"], "→", cf.evidence["n_objects_after"])
print("  关系数:", diff["n_relations_before"], "→", diff["n_relations_after"])
print("  消失了", len(diff["removed_relations"]), "条；翻转", len(diff["flipped_relations"]), "条")
print("  重跑视觉模型次数（应为 0）:", cf.evidence["models_rerun"])
print("  反事实后的最近邻（前 3）:")
nn2 = cf.value["relation_summary"]["nearest_neighbour"]
for oid, dd in sorted(nn2.items(), key=lambda kv: kv[1]["distance_m"])[:3]:
    print(f"    {oid} → {dd['object_id']}  {dd['distance_m']:.3f} m")
print("  移除后仍提到 sofa 的最近邻条数（应为 0）:",
      sum(1 for oid, dd in nn2.items() if "sofa" in oid or "sofa" in dd["object_id"]))

print()
bad = counterfactual(ctx, remove=["sofa_999"])
print("[counterfactual 幻觉 id] ok =", bad.ok, " code =", bad.error.code.value)
print("  known_ids 前 4:", (bad.error.context.get("known_ids") or [])[:4])
