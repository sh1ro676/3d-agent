# -*- coding: utf-8 -*-
"""
把 LLM_BACKEND.md 更新到 2026-09-17 的官方口径与实测结果。

一次改多处、每处都 assert 计数，避免同文件并发 Edit 互相覆盖
（那个坑本文件的 §4 里就记着）。
"""
import difflib
import os
import shutil

DOC = r'D:\3D_Spatial_Agent\phase0\LLM_BACKEND.md'
BAK = r'D:\3D_Spatial_Agent\logs\_pre_fix_LLM_BACKEND.bak'

shutil.copyfile(DOC, BAK)
s = open(DOC, encoding='utf-8').read()
orig = s
R = []

# ---------------------------------------------------------------- R1 方案甲
R.append((
    '### 方案甲：单端点（推荐起步）\n'
    'DeepSeek 在 **2026-08-21** 上线了多模态模型 `deepseek-v4-flash-vision-exp`。\n'
    '文本能力与 `deepseek-v4-flash` 持平，额外支持图片输入，**计价完全一样**。\n'
    '一个端点同时干「程序合成」和「vqa」，链路最简单，实验对照也最干净。',

    '### 方案甲：单端点（推荐起步）\n'
    'DeepSeek 的多模态能力现已并入 **`deepseek-flash`（DeepSeek-V4.1-Flash）**：\n'
    '它**支持图片输入**，且与纯文本同价。一个端点同时干「程序合成」和「vqa」，\n'
    '链路最简单，实验对照也最干净 —— 本机已实测 **视觉问答 4/4 全对**（见 §4.6）。\n'
    '\n'
    '> ⚠ **模型名口径 2026-09-17 有变，与本文上一版不同**。官方 `Models & Pricing` 页\n'
    '> 明写「请使用 `deepseek-flash` 作为模型名」，并把 `deepseek-v4-flash` 与\n'
    '> `deepseek-v4-flash-vision-exp` 列为**遗留别名** —— 原话是「对应模型已退役，\n'
    '> 请求由 DeepSeek-V4.1-Flash 承接，并按 Flash 价计费」。\n'
    '>\n'
    '> 本机实测印证了这一条：请求写的是 `deepseek-v4-flash-vision-exp`，\n'
    '> 响应里 `model_returned` 回的是 **`deepseek-flash`** —— 名字不一致，\n'
    '> 说明是端点做了规范化，而不是原样回显请求名。别名目前仍可用，\n'
    '> 但规范名更耐久（别名有被摘掉的风险）。',
))

# ---------------------------------------------------------------- R2 模型表
R.append((
    '| `deepseek-v4-flash` | DeepSeek | `https://api.deepseek.com` | 1M 上下文，支持 Tool Calls |\n'
    '| `deepseek-v4-pro` | DeepSeek | 同上 | 强模型对照臂 |\n'
    '| `deepseek-v4-flash-vision-exp` | DeepSeek | 同上 | **实验性**，唯一吃图的 DeepSeek 模型 |',

    '| **`deepseek-flash`** | DeepSeek | `https://api.deepseek.com` | **规范名**（= V4.1-Flash）。1M 上下文、384K 输出、**支持 Vision**、Tool Calls |\n'
    '| `deepseek-v4-flash` / `-vision-exp` | DeepSeek | 同上 | **遗留别名**，对应模型已退役，路由到 V4.1-Flash，同价 |\n'
    '| ~~`deepseek-v4-pro`~~ | DeepSeek | 同上 | **正在退役**：2026-09-14 12:00 起，请求全部路由到 V4.1-Flash |',
))

# ---------------------------------------------------------------- R3 价格表
R.append((
    'DeepSeek 价格（元/百万 token，高峰/空闲）：\n'
    '\n'
    '| 模型 | 输入(未命中) | 输入(命中) | 输出 |\n'
    '|---|---|---|---|\n'
    '| `deepseek-v4-flash` / `-vision-exp` | 3.0 / 1.5 | 0.10 / 0.05 | 9.0 / 4.5 |\n'
    '| `deepseek-v4-pro` | 9.0 / 4.5 | 0.30 / 0.15 | 27.0 / 13.5 |',

    'DeepSeek 价格（元/百万 token，**高峰 / 空闲**；V4 Pro 已并入 Flash，故只剩一档）：\n'
    '\n'
    '| 模型 | 输入(未命中) | 输入(命中) | 输出 |\n'
    '|---|---|---|---|\n'
    '| `deepseek-flash`（含全部遗留别名） | **3.0 / 1.5** | **0.10 / 0.05** | **9.0 / 4.5** |\n'
    '\n'
    '官方英文页同价（USD/百万）：未命中 `$0.30 / $0.15`、命中 `$0.006 / $0.003`、\n'
    '输出 `$1.20 / $0.60`。两处口径一致，可互相校对。\n'
    '\n'
    '> ⚠ **`deepseek-v4-pro` 已经不能当「强模型上界臂」用了**。官方称 V4.1 Flash\n'
    '> 在性能、成本、速度上已全面超越 V4 Pro，故**有序退役 V4 Pro**：自\n'
    '> 2026-09-14 12:00（北京时间）起，所有 `deepseek-v4-pro` 请求全部路由到\n'
    '> V4.1-Flash 并按 Flash 价计费。**换了名字不会换到更强的模型。**\n'
    '> 要强模型上界臂得换服务商（如 `qwen3-vl-plus`）。',
))

# ---------------------------------------------------------------- R4 坑5 实测结论
R.append((
    '`extra_body` + `thinking_observed` 汇总字段。',

    '`extra_body` + `thinking_observed` 汇总字段。\n'
    '\n'
    '#### 实测结论（2026-09-17，本机真实调用 15 次）\n'
    '\n'
    '**`{"thinking": {"type": "disabled"}}` 确实有效，走第 ① 条路。**\n'
    '\n'
    '| 臂 | 是否出现 `reasoning_content` | 中位延迟 | 输出 tokens（2 次合计） |\n'
    '|---|---|---|---|\n'
    '| `disabled`（带关闭参数） | **否**（2/2） | 0.98 s | **4** |\n'
    '| `default`（不带） | **是**（2/2） | 1.22 s | **51**（其中思考 45） |\n'
    '\n'
    '两臂分得很干净：带参数就没有思考痕迹，不带就有。所以：\n'
    '\n'
    '- **主路径（T1–T4，13 次调用）思考痕迹为 0 次** ⟹ `temperature=0.2` **真正生效**，\n'
    '  「低温可复现」这句话**站得住**，前提是实验章节写明「本臂关闭思考模式」。\n'
    '- 代价侧：同一句「只回一个词」的请求，开思考时**输出 token 是关闭时的 12.75 倍**\n'
    '  （51 vs 4），延迟 1.24 倍。程序合成的输出长达数百 token，**全量实验必须记账**。\n'
    '\n'
    '> ⚠⚠ **这里踩过一个坑，值得记住它长什么样。** 首轮报告的 `thinking_observed`\n'
    '> 输出了「思考模式生效 → `temperature` 被静默忽略 → **不得**声称低温可复现」，\n'
    '> 而同一份报告的 `thinking_ab` 却说「关闭参数有效」—— **同一份报告里两个相反结论**。\n'
    '> 根因不是测量错，是**派生错**：`observed_thinking()` 把 T1b 的 `default` 臂\n'
    '> 也算进了「主路径」统计，而那一臂是**故意**不带关闭参数的对照组，按定义就带思考。\n'
    '> 于是「整轮跑的是开还是关」恒判为「开」。\n'
    '>\n'
    '> **教训：一个统计量如果混入了它自己的对照组，就会给出与本实验相反的结论。**\n'
    '> 修法是把 T1b **按臂拆开**，只把与本次配置同臂的那一半并入主路径，\n'
    '> 对照组单独记字段。已修，并用原始记录离线复算验证。\n'
    '>\n'
    '> 同时修掉第二处派生错：`t1b_thinking_ab()` 只挑出 `completion_tokens` 两个字段、\n'
    '> 没保留整份 `usage`，而 `token_totals()` 只认 `r["usage"]` —— 于是 **T1b 在记账里\n'
    '> 恒为 0**。偏偏 T1b 就是「思考多花多少 token」那个实验，最不该漏。\n'
    '> 修正后总账 `1897 / 915` → **`1945 / 970`**（T1b 的 prompt 按 T1 同句提示词估算）。',
))

# ---------------------------------------------------------------- R5 上界臂
R.append((
    '- 想保留一个"强模型上界臂"，用 `deepseek-v4-pro` 或 `qwen3-vl-plus`，\n'
    '  不需要 OpenAI。',

    '- 想保留一个「强模型上界臂」，**DeepSeek 这边已经没有了**（V4 Pro 已路由到 Flash）。\n'
    '  需要换服务商，例如 `qwen3-vl-plus`。不需要 OpenAI。',
))

# ---------------------------------------------------------------- R6 成本估算换成实测
R.append((
    '**成本量级估算**（需你实测替换）：每道题 ≈ 4 次文本调用（Signature/API/Program/修复）\n'
    '+ N 次 `vqa()`。假设每次输入 5k tokens、Omni3D-Bench 1000 题、n=3 次 vqa：\n'
    '文本约 20M 输入 tokens，按 `deepseek-v4-flash` 高峰价 3 元/M ≈ 60 元，\n'
    '空闲价 ≈ 30 元。**先跑 20 题小样本量出真实 token 数，再外推全量。**',

    '**成本：探针实测的每次调用 token 数（这是下限，不是估计）**\n'
    '\n'
    '| 探针项 | 对应 VADAR 环节 | prompt/次 | completion/次 |\n'
    '|---|---|---|---|\n'
    '| T2 | ProgramAgent 程序合成 | 152 | 183 |\n'
    '| T3 | SignatureAgent 签名 | 131 | 80 |\n'
    '| T4 | `vqa()`（含一张图） | 259 | 31 |\n'
    '| T1 | 连通性 | 12 | 2 |\n'
    '\n'
    '**整轮探针（15 次调用）合计 1945 prompt + 970 completion = 2915 tokens，\n'
    '空闲档 ¥0.0073，高峰档 ¥0.0146。** 一次不到一分钱。\n'
    '\n'
    '> ⚠ **不要把上表直接乘题数外推。** 探针用的是**极简提示词**，\n'
    '> 而真实 VADAR 的 prompt 要带上完整 API 文档 + few-shot 示例，\n'
    '> 输入长度会高一个量级；`vqa()` 的图片 token 也随分辨率上升\n'
    '> （探针用的是合成小图）。**真实 per-call 数只能由「跑臂」运行器量出来** ——\n'
    '> 探针能证明的只是「端点机制与计价口径没问题」。',
))

# ---------------------------------------------------------------- R7 命令
R.append((
    'python 02_probe_llm_api.py --base-url https://api.deepseek.com \\\n'
    '                           --model deepseek-v4-flash-vision-exp \\\n'
    '                           --api-key sk-xxxx \\\n'
    '                           --price-in <元/百万> --price-out <元/百万>   # 可选，填了才给费用外推',

    'python 02_probe_llm_api.py --base-url https://api.deepseek.com \\\n'
    '                           --model deepseek-flash \\\n'
    '                           --api-key sk-xxxx \\\n'
    '                           --price-in 3.0 --price-out 9.0   # 高峰价；填了才给费用外推',
))

# ---------------------------------------------------------------- R8 环境变量
R.append((
    'export VADAR_MODEL=deepseek-v4-flash-vision-exp',
    'export VADAR_MODEL=deepseek-flash          # 规范名；遗留别名 v4-flash / vision-exp 仍可用',
))

for i, (old, new) in enumerate(R, 1):
    c = s.count(old)
    assert c == 1, 'R%d: count=%d (expected 1)\n%s' % (i, c, old[:90])
    s = s.replace(old, new, 1)

open(DOC, 'w', encoding='utf-8', newline='').write(s)

print('LLM_BACKEND.md: %d -> %d chars' % (len(orig), len(s)))
print('替换生效 %d 处\n' % len(R))

d = list(difflib.unified_diff(orig.splitlines(), s.splitlines(),
                              'before', 'after', lineterm='', n=0))
hunks = sum(1 for l in d if l.startswith('@@'))
print('diff hunks:', hunks, '| added:', sum(1 for l in d if l.startswith('+') and not l.startswith('+++')),
      '| removed:', sum(1 for l in d if l.startswith('-') and not l.startswith('---')))
print()
print('=== 旧串残留检查（应全为 0） ===')
for k in ['deepseek-v4-flash-vision-exp', 'deepseek-v4-flash`', 'deepseek-v4-pro`',
          '2026-08-21', '需你实测替换']:
    print('  %-32r: %d' % (k, s.count(k)))
print()
print('=== 新口径落地检查 ===')
for k in ['deepseek-flash', 'DeepSeek-V4.1-Flash', '遗留别名', '12.75 倍',
          '1945 / 970', '¥0.0073', '有序退役 V4 Pro']:
    print('  %-32r: %d' % (k, s.count(k)))
