# -*- coding: utf-8 -*-
"""
用已落盘的报告记录**离线复算**两个派生字段，验证修补是否给出正确结论。

要点：
  - 原始响应记录（每次调用的 has_reasoning / usage / elapsed）**一个字节都不改**；
  - 只重算 thinking_observed 与 token_totals 这两个「派生块」；
  - 修复原因、旧值、新值全部写进报告的 derived_recomputed 块，可追溯；
  - 复算不需要任何 API 调用（纯派生，零额度）。
"""
import importlib.util
import json
import os
import shutil
import time

ROOT = r'D:\3D_Spatial_Agent'
PROBE = os.path.join(ROOT, 'phase0', '02_probe_llm_api.py')
REPORT = os.path.join(ROOT, 'phase0', 'llm_probe_report.json')
ARCHIVE = os.path.join(ROOT, 'logs', 'phase1_probe_raw_2026-09-17.json')

spec = importlib.util.spec_from_file_location('probe', PROBE)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)

d = json.load(open(REPORT, encoding='utf-8'))
cfg = d['config']
t1 = d['t1_connectivity']
t1b = d['t1b_thinking_ab']
t2 = d['t2_program']
t3 = d['t3_signature']
t4 = d['t4_vision']

old_obs = d['thinking_observed']
old_tok = d['token_totals']

# ---- T1b 的 usage：本轮未记录，用 T1 的 prompt 数（同一句提示词）补成估算值 ----
T1_PROMPT = (t1.get('usage') or {}).get('prompt_tokens')
t1b_filled = []
for r in t1b:
    r2 = dict(r)
    if not r2.get('usage'):
        ct = r2.get('completion_tokens') or 0
        r2['usage'] = {'prompt_tokens': T1_PROMPT,
                       'completion_tokens': ct,
                       'total_tokens': (T1_PROMPT or 0) + ct,
                       '_estimated': '本轮 T1b 未记录 usage，prompt 沿用 T1 同句提示词的值'}
    t1b_filled.append(r2)

new_obs = probe.observed_thinking(cfg, t1, t1b, t2, t3, t4)
new_tok = probe.token_totals(cfg, t1, t1b_filled, t2, t3, t4)

print('=' * 74)
print('【A】thinking_observed  —— 旧值 vs 复算值')
print('=' * 74)
for k in ('calls_ok', 'calls_with_reasoning', 'has_reasoning', 'main_path_arm',
          'excluded_control_arm_calls_ok', 'excluded_control_arm_with_reasoning'):
    print('  %-38s %-8s -> %s' % (k, old_obs.get(k, '(无)'), new_obs.get(k, '(无)')))
print()
print('  旧 note :', old_obs.get('note'))
print('  新 note :', new_obs.get('note'))

print()
print('=' * 74)
print('【B】token_totals  —— 旧值 vs 复算值')
print('=' * 74)
print('  %-8s %-26s %-26s' % ('测试', '旧 (prompt/completion)', '复算 (prompt/completion)'))
oldmap = {r['test']: r for r in old_tok['by_test']}
newmap = {r['test']: r for r in new_tok['by_test']}
for name in ('T1', 'T1b', 'T2', 'T3', 'T4'):
    o = oldmap.get(name); n = newmap.get(name)
    f = lambda r: '%s / %s' % (r['prompt_tokens'], r['completion_tokens']) if r else '-'
    print('  %-8s %-26s %-26s' % (name, f(o), f(n)))
print('  %-8s %-26s %-26s' % ('合计',
                             '%s / %s' % (old_tok['total_prompt'], old_tok['total_completion']),
                             '%s / %s' % (new_tok['total_prompt'], new_tok['total_completion'])))

# ---------------- 费用（官方价，需人工核对时段） ----------------
# 官方 api-docs.deepseek.com/quick_start/pricing（2026-09 查）
# deepseek-flash  输入(未命中) / 输出   空闲 $0.15/$0.60  高峰 $0.30/$1.20（每百万）
# 官方中文公告：空闲 ¥1.5/¥4.5，高峰 ¥3.0/¥9.0（每百万）
# 高峰 = 北京时间 09:00-12:00、14:00-18:00；本次运行 19:42 -> 空闲
p_in, p_out = 1.5, 4.5
cost = new_tok['total_prompt'] / 1e6 * p_in + new_tok['total_completion'] / 1e6 * p_out
cost_peak = cost * 2
no_t1b = old_tok['total_prompt'] / 1e6 * p_in + old_tok['total_completion'] / 1e6 * p_out
print()
print('  本次运行时段：19:42 北京 -> 空闲档')
print('  费用（含 T1b 估算）: ¥%.5f  | 若走高峰档: ¥%.5f' % (cost, cost_peak))
print('  费用（不含 T1b 估算）: ¥%.5f' % no_t1b)

# ---------------- 思考模式的 token 代价 ----------------
off = [r for r in t1b if r['arm'] == 'disabled']
on = [r for r in t1b if r['arm'] == 'default']
oc = sum(r['completion_tokens'] for r in off)
nc = sum(r['completion_tokens'] for r in on)
nr = sum((r.get('reasoning_tokens') or 0) for r in on)
print()
print('=' * 74)
print('【C】思考模式的代价（同一句「回一个词」的请求）')
print('=' * 74)
print('  关闭思考: 输出 %d tokens（2 次合计），思考 token 0' % oc)
print('  开启思考: 输出 %d tokens（2 次合计），其中思考 token %d' % (nc, nr))
print('  -> 输出 token 放大 %.2f 倍' % (nc / oc if oc else 0))
print('  延迟中位数: %.2fs (关) vs %.2fs (开)  -> %.2f 倍'
      % (d['thinking_ab']['disabled_median_elapsed'],
         d['thinking_ab']['default_median_elapsed'],
         d['thinking_ab']['default_median_elapsed'] / d['thinking_ab']['disabled_median_elapsed']))

# ---------------- 落盘：归档原件 + 定点修补 ----------------
if not os.path.exists(ARCHIVE):
    shutil.copyfile(REPORT, ARCHIVE)
    print()
    print('原始报告已归档:', ARCHIVE)

d['thinking_observed'] = new_obs
d['token_totals'] = new_tok
d['derived_recomputed'] = {
    'when': time.strftime('%Y-%m-%d %H:%M:%S'),
    'why': ('探针两处「派生」bug：① observed_thinking 把 T1b 的对照组算进主路径，'
            '产出与 thinking_ab 相反的结论；② T1b 未保留整份 usage，token 记账恒为 0。'
            '已修 02_probe_llm_api.py；本块是用**原始记录离线复算**的结果。'),
    'raw_records_untouched': True,
    'old_thinking_observed': old_obs,
    't1b_usage_note': ('本轮 T1b 未记录 usage，prompt 按 T1 同句提示词的 %s tokens 估算；'
                       'completion (%d) 为记录值，精确。下次重跑即为精确值。'
                       % (T1_PROMPT, sum(r['completion_tokens'] for r in t1b))),
    'cost_cny_offpeak_prices': {'price_in': p_in, 'price_out': p_out, 'cost': round(cost, 6),
                                'cost_peak': round(cost_peak, 6)},
}
json.dump(d, open(REPORT, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('报告已定点修补（原始记录未动）')
