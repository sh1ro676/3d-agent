# -*- coding: utf-8 -*-
"""
一次性修补：02_probe_llm_api.py 的两处「派生」bug + 统一模型名。

两处 bug 都不是测量错，而是**派生错** —— 原始响应记录是对的，
是汇总/记账那一步把结果算成了相反的结论。这类 bug 最危险：
报告读起来像数据，其实是代码的推断。

  1) observed_thinking() 把 T1b 的**对照组**算进了主路径统计。
     T1b 的 default 臂按构造就带思考，于是「整轮跑的是开还是关」
     恒为「开」，note 还会输出「不得声称低温可复现」——
     与同一份报告里的 thinking_ab（disable 参数有效）**直接矛盾**。
  2) t1b_thinking_ab() 只挑了 completion_tokens 两个字段，
     没保留整份 usage。token_totals() 只认 r["usage"]，
     于是 T1b 在记账里恒为 0 —— 而 T1b 恰恰是
     「思考模式多花多少 token」的那个实验，最不该漏。
"""
import os
import difflib
import py_compile

PROBE = r'D:\3D_Spatial_Agent\phase0\02_probe_llm_api.py'
PS1 = r'D:\3D_Spatial_Agent\phase0\06_deepseek_setup.ps1'
BRIDGE = r'D:\3D_Spatial_Agent\phase0\03_vadar_llm_bridge.py'
BAK = r'D:\3D_Spatial_Agent\logs\_pre_fix_probe.bak'

OLD_MODEL = 'deepseek-v4-flash-vision-exp'
NEW_MODEL = 'deepseek-flash'

# ---------------------------------------------------------------- 1) 探针
raw = open(PROBE, 'rb').read()
open(BAK, 'wb').write(raw)
s = raw.decode('utf-8')
orig = s
pairs = []

# --- 1a) T1b 保留整份 usage ---
old_1a = '''                "has_reasoning": r.get("has_reasoning"),
                "completion_tokens": u.get("completion_tokens"),
                "reasoning_tokens": cdet.get("reasoning_tokens"),'''
new_1a = '''                "has_reasoning": r.get("has_reasoning"),
                # 必须保留**整份** usage：token_totals() 只认 r["usage"]。
                # 老版本这里只挑出两个字段，于是 T1b 在记账里恒为 0 ——
                # 而 T1b 恰恰是「思考模式多花多少 token」的那个实验，最不该漏。
                "usage": u,
                "completion_tokens": u.get("completion_tokens"),
                "reasoning_tokens": cdet.get("reasoning_tokens"),'''
pairs.append((old_1a, new_1a, 1, '1a T1b 保留 usage'))

# --- 1b) observed_thinking 排除对照组 ---
old_1b = '''    """
    汇总「本轮所有成功调用里，思考痕迹出现了几次」。
    以前报告只记 T1 一条 has_reasoning，事后无法判断整轮跑的是开还是关。
    """
    calls = []
    for r in [t1] + list(t1b or []) + list(t2 or []) + list(t3 or []) + list(t4 or []):
        if r and r.get("ok"):
            calls.append(r)
    n = sum(1 for c in calls if c.get("has_reasoning"))
    out = {
        "extra_body_sent": cfg.get("extra_body"),
        "temperature_configured": cfg.get("temperature"),
        "calls_ok": len(calls),
        "calls_with_reasoning": n,
        "has_reasoning": (n > 0) if calls else None,
    }'''
new_1b = '''    """
    汇总「主路径这一轮实际跑的是开还是关」。

    [!] T1b 必须**按臂拆开**再并入。T1b 的 default 臂是刻意构造的对照组，
        按定义就带思考；若把它算进「整轮跑的是开还是关」，
        本函数会恒判「思考开启」，并输出「不得声称低温可复现」的法令式结论 ——
        与同一份报告里的 thinking_ab（disable 参数有效）**直接矛盾**。
        两臂对比是 thinking_ab 的职责，本函数只回答主路径。
    """
    main_arm = None
    if t1b:
        cfg_eb = cfg.get("extra_body") or None
        if cfg_eb is None:
            main_arm = "default"
        elif cfg_eb == THINKING_DISABLED:
            main_arm = "disabled"
        # 自定义 extra_body 时无法确认它属于哪一臂 -> 不并入主路径统计
    t1b_main = [r for r in (t1b or []) if main_arm and r.get("arm") == main_arm]
    t1b_ctrl = [r for r in (t1b or []) if not (main_arm and r.get("arm") == main_arm)]

    calls = []
    for r in [t1] + t1b_main + list(t2 or []) + list(t3 or []) + list(t4 or []):
        if r and r.get("ok"):
            calls.append(r)
    n = sum(1 for c in calls if c.get("has_reasoning"))
    ctrl = [r for r in t1b_ctrl if r and r.get("ok")]
    out = {
        "extra_body_sent": cfg.get("extra_body"),
        "temperature_configured": cfg.get("temperature"),
        "main_path_arm": main_arm,
        "calls_ok": len(calls),
        "calls_with_reasoning": n,
        "has_reasoning": (n > 0) if calls else None,
        "excluded_control_arm_calls_ok": len(ctrl),
        "excluded_control_arm_with_reasoning": sum(1 for r in ctrl if r.get("has_reasoning")),
        "excluded_control_arm_note": (
            "T1b 对照组按构造就会带思考，已排除在主路径统计之外，"
            "不是反例；两臂对比见 thinking_ab。"),
    }'''
pairs.append((old_1b, new_1b, 1, '1b observed_thinking 排除对照组'))

# --- 1c) 统一模型名 ---
pairs.append((
    OLD_MODEL, NEW_MODEL, 3,
    '1c 模型名 -> %s' % NEW_MODEL))

for old, new, expect, label in pairs:
    c = s.count(old)
    assert c == expect, '%s: count=%d, expected %d' % (label, c, expect)
    s = s.replace(old, new)

# 在默认值旁加一句「别改回去」
anchor = 'ap.add_argument("--model", default=os.environ.get("VADAR_MODEL",'
note = ('# 官方 2026-09 口径：deepseek-flash 为规范名；deepseek-v4-flash 与\n'
        '# deepseek-v4-flash-vision-exp 是**遗留别名**，对应模型已退役，\n'
        '# 请求统一由 DeepSeek-V4.1-Flash 承接（支持 Vision），按 Flash 价计费。\n'
        '# 别名当前仍可用，但规范名更耐久 —— 别"好心"改回带 vision-exp 的旧名。\n')
c = s.count(anchor)
assert c == 1, 'model anchor count=%d' % c
s = s.replace(anchor, note + anchor, 1)

open(PROBE, 'w', encoding='utf-8', newline='').write(s)

# ---------------------------------------------------------------- 2) PS1
rawp = open(PS1, 'rb').read()
assert rawp[:3] == b'\xef\xbb\xbf', 'PS1 BOM missing before edit'
old_crlf = rawp.count(b'\r\n')
sp = rawp.decode('utf-8-sig')
assert sp.count(OLD_MODEL) == 1, 'PS1 model count=%d' % sp.count(OLD_MODEL)
sp = sp.replace(OLD_MODEL, NEW_MODEL)
open(PS1, 'wb').write(sp.encode('utf-8-sig'))
rawp2 = open(PS1, 'rb').read()
assert rawp2[:3] == b'\xef\xbb\xbf', 'PS1 BOM LOST'
assert rawp2.count(b'\r\n') == old_crlf, 'PS1 CRLF changed'

# ---------------------------------------------------------------- 3) bridge
rawb = open(BRIDGE, 'rb').read()
sb = rawb.decode('utf-8')
c = sb.count(OLD_MODEL)
assert c == 4, 'bridge model count=%d' % c
sb = sb.replace(OLD_MODEL, NEW_MODEL)
open(BRIDGE, 'w', encoding='utf-8', newline='').write(sb)

# ---------------------------------------------------------------- 校验
py_compile.compile(PROBE, doraise=True)
py_compile.compile(BRIDGE, doraise=True)
print('COMPILE OK (probe + bridge)')
print('PS1: BOM=True CRLF=%d->%d' % (old_crlf, rawp2.count(b'\r\n')))
print()

print('=== 探针 diff（相对修补前） ===')
a = open(BAK, encoding='utf-8').read().splitlines()
b = open(PROBE, encoding='utf-8').read().splitlines()
d = list(difflib.unified_diff(a, b, 'before', 'after', lineterm='', n=1))
adds = [l for l in d if l.startswith('+') and not l.startswith('+++')]
dels = [l for l in d if l.startswith('-') and not l.startswith('---')]
print('added %d lines | removed %d lines' % (len(adds), len(dels)))
print('=== 被删除的行（应全部是有意替换的旧版本） ===')
for l in dels:
    print('  ', l)
