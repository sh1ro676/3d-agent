# -*- coding: utf-8 -*-
"""把方案文档的 DeepSeek 口径同步到 2026-09-17 官方/实测结论。"""
import difflib
import shutil

DOC = r'D:\3D_Spatial_Agent\docs\3D_Spatial_Agent_技术调研与实施方案.md'
BAK = r'D:\3D_Spatial_Agent\logs\_pre_fix_doc.bak'

shutil.copyfile(DOC, BAK)
s = open(DOC, encoding='utf-8').read()
orig = s
R = []

# ---- P1 档 B 的文本模型名 ----
R.append((
    '**档 B — 双端点（成本优化）**\n'
    '文本 Agent → `deepseek-v4-flash`（或 `-pro`）；\n',

    '**档 B — 双端点（成本优化）**\n'
    '文本 Agent → `deepseek-flash`（**规范名**；`deepseek-v4-flash` / `-vision-exp` 是遗留别名，\n'
    '`-pro` 已并入 Flash，见 §7.4）；\n',
))

# ---- P2+P3 坑 5 那一行 + 新增 §7.4 实测记录 ----
R.append((
    '| 5 | 全局 | DeepSeek V4 默认思考模式，拉长延迟，可能撞 `engine.py:594` 的 200s 超时 '
    '| `VADAR_EXTRA_BODY` 原样透传，不猜参数名 |\n',

    '| 5 | 全局 | DeepSeek V4 默认思考模式：拉长延迟（**同一句「回一个词」输出 token ×12.75**），'
    '可能撞 `engine.py:594` 的 200s 超时；**且会让 `temperature` 静默失效** '
    '| `VADAR_EXTRA_BODY=\'{"thinking":{"type":"disabled"}}\'` —— **参数名已核实、A/B 实测有效**（§7.4）|\n'
    '\n'
    '### 7.4 DeepSeek 后端实测（2026-09-17，真实调用 15 次）\n'
    '\n'
    '**（1）模型名口径已变（官方 `Models & Pricing` 页）**\n'
    '\n'
    '| 名字 | 状态 |\n'
    '|---|---|\n'
    '| **`deepseek-flash`**（= DeepSeek-V4.1-Flash） | **规范名**。1M 上下文、384K 输出、**支持 Vision**、Tool Calls |\n'
    '| `deepseek-v4-flash` / `deepseek-v4-flash-vision-exp` | **遗留别名**。对应模型**已退役**，请求由 V4.1-Flash 承接，同价 |\n'
    '| `deepseek-chat` / `deepseek-reasoner` | 2026-07-24 已退役 |\n'
    '| `deepseek-v4-pro` | **有序退役中**：2026-09-14 12:00 起请求全部路由到 V4.1-Flash |\n'
    '\n'
    '本机实测印证：请求写 `deepseek-v4-flash-vision-exp`，响应 `model_returned` 回的是\n'
    '`deepseek-flash` —— 名字不一致，说明是端点做了规范化，不是原样回显。\n'
    '价格（元/百万，**高峰 / 空闲**）：输入未命中 `3.0 / 1.5`、命中 `0.10 / 0.05`、输出 `9.0 / 4.5`。\n'
    '高峰 = 北京时间 9:00–12:00 与 14:00–18:00。\n'
    '\n'
    '> ⚠ **上界臂要换服务商了**：V4 Pro 路由到 Flash 后，**DeepSeek 这边已不存在「强模型档」**，\n'
    '> 换了名字不会换到更强的模型。见 §11.6 的基线说明。\n'
    '\n'
    '**（2）思考模式 A/B —— 关闭参数有效，低温可复现站得住**\n'
    '\n'
    '| 臂 | 出现 `reasoning_content` | 中位延迟 | 输出 tokens（2 次合计） |\n'
    '|---|---|---|---|\n'
    '| `disabled`（带关闭参数） | **否**（2/2） | 0.98 s | **4** |\n'
    '| `default`（不带） | **是**（2/2） | 1.22 s | **51**（其中思考 45） |\n'
    '\n'
    '主路径（T1–T4，13 次调用）**思考痕迹 0 次** ⟹ `temperature=0.2` **真正生效**，\n'
    '实验章节可以声称「本臂关闭思考模式、低温可复现」——但**必须写明这句话**。\n'
    '代价侧：开思考时输出 token 是无思考的 **12.75 倍**（同一句「只回一个词」），\n'
    '程序合成的输出长达数百 token，**全量实验必须逐臂记账**。\n'
    '\n'
    '**（3）四类标签与视觉通道：全绿**\n'
    '\n'
    '| 项 | 对应 VADAR 环节 | 结果 |\n'
    '|---|---|---|\n'
    '| `<program>` 标签 + 语法 | ProgramAgent / Engine | **3/3**，全部 `ast.parse` 通过 |\n'
    '| 签名提取 | SignatureAgent / APIAgent | **3/3**；`has_return_annotation=False` ⟹ **坑 2 未触发** |\n'
    '| `<answer>` 标签 | `VQAModule.predict` | **4/4** |\n'
    '| 视觉问答答对率 | `vqa()` | **4/4**（主模型直接吃图，无需独立视觉端点） |\n'
    '\n'
    '> ⚠ **「未触发」≠「不存在」**：坑 2 的正则确实排斥返回值注解，只是 `deepseek-flash`\n'
    '> 这三次都没给注解。换提示词或换模型仍可能触发，Phase 3 的提示词约束不要撤。\n'
    '\n'
    '**（4）成本**：整轮 15 次调用 **1945 prompt + 970 completion = 2915 tokens**，\n'
    '空闲档 **¥0.0073**、高峰档 ¥0.0146。\n'
    '⚠ 这是**下限**：探针用的是极简提示词，真实 VADAR prompt 要带完整 API 文档 + few-shot，\n'
    '输入会高一个量级。**真实 per-call 数只能由「跑臂」运行器量出来** ——\n'
    '探针能证明的只是「端点机制与计价口径没问题」。\n'
    '\n'
    '> **一次值得写进报告的「差点搞错」**：首轮报告的汇总字段 `thinking_observed`\n'
    '> 曾给出**相反结论**（「思考生效 → `temperature` 被忽略 → 不得声称低温可复现」）。\n'
    '> 根因是派生代码把 A/B 的**对照组**算进了主路径统计（那一臂故意带思考）。\n'
    '> 已修 + 离线复算验证，原始报告归档在 `logs/phase1_probe_raw_2026-09-17.json`。\n'
    '> 教训：**一个统计量混入它自己的对照组，就会得出与本实验相反的结论**。\n',
))

# ---- P4 上界臂建议 ----
R.append((
    '> （建议 `deepseek-v4-pro` 或 `qwen3-vl-plus`），这样 A–F 全部跑在同一服务商、\n'
    '> 同一套参数、同一份数据上，内部一致性反而比跨服务商对比更好。',

    '> —— 注意 **DeepSeek 这边已无强模型档**：`deepseek-v4-pro` 自 2026-09-14 12:00 起\n'
    '> 全部路由到 V4.1-Flash（见 §7.4），换了名字不会换到更强的模型。\n'
    '> 所以要上界臂就得**跨服务商**（如 `qwen3-vl-plus`），或者把上界臂定义为\n'
    '> 「同一模型 + 更多推理预算（思考模式开启」），但那混淆了模型与推理预算两个变量，\n'
    '> 需要在表里单独说明。其余各臂仍跑在同一服务商、同一套参数、同一份数据上，\n'
    '> 内部一致性比跨服务商对比更好。',
))

# ---- P5 探针命令 ----
R.append((
    'python 02_probe_llm_api.py --base-url https://api.deepseek.com \\\n'
    '                           --model deepseek-v4-flash-vision-exp \\\n'
    '                           --api-key sk-xxxx\n',

    'python 02_probe_llm_api.py --base-url https://api.deepseek.com \\\n'
    '                           --model deepseek-flash \\\n'
    '                           --api-key sk-xxxx \\\n'
    '                           --price-in 3.0 --price-out 9.0   # 高峰价；填了才给费用外推\n',
))

# ---- P6 05 探针命令 ----
R.append((
    '--model deepseek-v4-flash --api-key sk-xxxx',
    '--model deepseek-flash --api-key sk-xxxx',
))

for i, (old, new) in enumerate(R, 1):
    c = s.count(old)
    assert c == 1, 'P%d: count=%d (expected 1)\n%r' % (i, c, old[:100])
    s = s.replace(old, new, 1)

open(DOC, 'w', encoding='utf-8', newline='').write(s)

print('方案文档: %d -> %d chars (+%d)' % (len(orig), len(s), len(s) - len(orig)))
print('替换生效 %d 处\n' % len(R))
d = list(difflib.unified_diff(orig.splitlines(), s.splitlines(),
                              'before', 'after', lineterm='', n=0))
print('diff hunks:', sum(1 for l in d if l.startswith('@@')),
      '| added:', sum(1 for l in d if l.startswith('+') and not l.startswith('+++')),
      '| removed:', sum(1 for l in d if l.startswith('-') and not l.startswith('---')))
print()
print('=== 残留旧口径（除说明性提及外应为 0） ===')
for k in ['--model deepseek-v4-flash-vision-exp', '--model deepseek-v4-flash ',
          '建议 `deepseek-v4-pro`', '不猜参数名']:
    print('  %-40r: %d' % (k, s.count(k)))
print()
print('=== 新内容落地 ===')
for k in ['### 7.4 DeepSeek 后端实测', 'deepseek-flash', 'V4.1-Flash',
          '12.75', '1945 prompt + 970', '¥0.0073', '未触发」≠「不存在']:
    print('  %-40r: %d' % (k, s.count(k)))
