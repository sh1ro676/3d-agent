# 项目长期记忆 — 3D Spatial Agent（基于 VADAR）

> **本文件只是索引 + 决策台账，不复制文档。** 细节以
> `D:\3D_Spatial_Agent\docs\3D_Spatial_Agent_技术调研与实施方案.md`（**§21 最新**）
> 与 `README.md` 为准；代码注释里写满了「为什么」。只留「不写下来就会重新踩一次」的东西。

## 0. 状态与下一步（2026-09-16 夜）

**Phase 0 环境 + Phase 1b 骨架 + Phase 1c 感知层/builder 全部跑通。全程 Windows 原生，未装 WSL。**

| 已完成 | 证据 |
|---|---|
| venv `D:\3D_Spatial_Agent\venvs\vision`（3.12.5）+ torch 2.6.0+cu124 | `verify_env.py` exit 0；**xformers/triton 全缺仍 `import UniDepthV2` 成功** |
| 三模型显存/延迟全实测 | UniDepth 486/604 MB·1120 ms；GDINO 1903/2306 MB·814 ms；SAM2 647/928 MB·282 ms；**常驻合计 1146.7 MB = 8188 MiB 的 14.0%**，峰值 2177 MB |
| **L1 感知层 + builder + store 落地** | `vision/{types,geometry,grounding,segmentation,depth,registry}.py`、`scene_graph/{builder,store}.py` |
| **真实照片产出场景图** | `dataset\scenes\living_room_gt\`（9 物体 / 137 关系）；同图 A/B 对照 `living_room_pred\` |
| 全部单测 | **166 passed in 0.93 s，零 GPU、零联网** |

**悬空项已清零。下一步**：① L5 报告层（`describe_scene` / `diagnose_failure`）；
② 真实照片无 GT 内参时的 EXIF 等效焦距估算（`fx_px ≈ f_35mm/36 × 宽`）；③ 多图复跑验证内参杠杆的普遍性。

## 1. ⭐⭐ 内参杠杆（2026-09-16 发现，本阶段最重要）

**UniDepth V2 的相机头不可信，但它接受外部相机条件 —— 这一条决定全部横向米制尺度。**

用仓库自带配对的 GT 深度（`vendor/UniDepth/assets/demo/depth.png`，毫米）逐像素对照：

| 路径 | 深度 ARel | δ<1.25 | **三维误差中位** | 三维相对中位 |
|---|---|---|---|---|
| `infer(rgb)` 让模型猜相机 | 19.8% | 57.1% | **1.943 m** | 59.0% |
| `infer(rgb, camera=GT K)` | 11.7% | 93.2% | **0.267 m** | 9.1% |

同图同权重，**三维误差中位数差 7.3 倍**。真值 fx=518.9（HFoV 63.3°）vs 预测 fx=163.7（**125.8°**），横向放大 **3.169×**。

**四条必须记住的细节：**
1. **官方 README 误导**：写成 GT 内参 "as **well**"（锦上添花），但官方 `scripts/demo.py:14` **自己就传 camera** —— 作者从不用纯 RGB 路径验证。
2. **传进去的 camera 不会改写回传的 `intrinsics`** —— 那是独立预测头，传 GT 后仍返回 163.7。
   生效路径是 `unidepthv2.py:361-362`（camera → `rays` 喂进 decoder 当条件）。
   ⟹ `DepthField.intrinsics` 必须记**实际生效的那一份**，否则 scene.json 里的 K 与点云不自洽。
   规则集中在 `vision/depth.py::resolve_intrinsics()`（纯函数，有单测）。
3. **内参错是各向异性的**：`x=(u-cx)·z/fx`，fx 小 k 倍 ⟹ 横向大 k 倍而 z 几乎不动。
   ⟹ 全局 `scale_factor` 修不了它 —— **原方案的 `calibrate_scale` 据此撤销**。正确做法是把内参当**输入**。
4. **二级效应（意外）**：内参错还毁掉重力方向估计 —— 同图 tilt **11.95°(reliable) → 63.04°(不可靠)**，
   而 `above`/`below` 全依赖 up 轴 ⟹ **内参错会静默翻转所有上下关系**，不只是放大尺寸。

**用法**：`BuildConfig.known_intrinsics=(fx,fy,cx,cy)`；CLI `--intrinsics auto|<npy>|"fx,fy,cx,cy"`。
无已知内参时标 `intrinsics_source="predicted"` + 视场检查（可信区间 30°–110°，`PLAUSIBLE_HFOV_DEG`）并**发警告**。
探针 `phase0/probe_depth_gt.py`。**Omni3D-Bench 自带 GT 相机 ⟹ 主实验臂横向尺度可控，这是有利条件。**

## 2. ⭐ UniDepth `points` 是真几何（创新点 1 的地基）

源码：`unidepthv2.py:375` rays → `:376 pts_3d = rays*radius` → `:377 depth = pts_3d[:,-1:]`；`infer()` 内 `:334/:335` 同义。
实测：`points[2] - depth` = **0.000e+00**；`norm(points)==radius` 精确；34.2 M / 130.4 MB；`infer()` 返回 7 键。

1. **`depth` 不是独立测量量** —— 就是点云 z 列。VADAR 拿到完整 XYZ 却只留 z（`predefined_modules.py:375/:395`）。
   **升级到真三维不需要任何新模型、任何新显存。**
2. **VADAR 的 3D 尺寸公式量纲不成立** —— `2D 像素 × depth`，整个式子没有焦距。
3. **不要用 `intrinsics` 反投影重建点云** —— `rays` 是 decoder 预测的方向场；两者差 3–5% 属正常，**直接用 `points`**。

## 3. 感知层与 builder 的关键实现裁决

| # | 裁决 | 依据 |
|---|---|---|
| ① | 质心取 **SAM2 掩码**内点云中位数，框只作降级路径（标 `centroid_source="bbox_fallback"`） | 框内中位数 vs 掩码质心差 **均值 83 mm / 最大 208 mm**，关系容差只有 50 mm |
| ② | SAM2 **一次调用带全部框** | 9 框：批量 179–200 ms vs 逐个 1512 ms，**7.57×**；由接口形状保证（`segment()` 无单框重载） |
| ③ | 模型句柄必须是**实例属性** | 放局部变量会测出「常驻 291 MB」，真值 1200 MB（函数返回即回收） |
| ④ | 内参是**逐图输入**（`lift(image, camera_K=)`），不挂 `PerceptionStack` | cx/cy 与分辨率绑定；registry 只管模型生命周期 |
| ⑤ | **不做尺度校正**，`scale_factor` 恒 1.0，`scale_calibrated=False` | 见 §1.3 |

**分层**：`vision/types.py` + `geometry.py` 零 torch，`depth.py` 的 torch 也在函数内 import
⟹ builder 全部分支可在 0.93 s 内测完且不需要 GPU。`PerceptionLike` 只有 3 个方法，测试里 30 行写一个 fake。

**关系边只按 `(i,j)` 且 i 小于 j 单方向枚举**，`far` 不存（是 `near` 补集），反向关系由 `query_relation` 现算。

## 4. 定位与硬约束

把 VADAR（CVPR 2025）升级为 **3D Spatial Agent**：3D Vision → 3D Spatial Representation（Scene Graph + Geometry）
→ LLM Agent → 交互式 3D Demo。用途：课程大作业 + 答辩 + 简历。

- 硬件上限 RTX 4060 Laptop 8188 MiB。**不做从零训练 7B/14B**；训练上限 3B–4B QLoRA。
- **VADAR 只作参考、不是底座**：只借**动作空间设计**（LLM 输出 Python 程序而非 JSON tool call），
  弃用其 agent 层 / Engine 层 / 运行时随机生成 API。**最重要的一条定位。**
- **一切空间关系由几何计算得出**，不由 LLM/VLM 判断；VLM 只判颜色/材质等语义属性。
- 固定工具库 + 版本号，保证评测可复现。只做能实测验证的创新点（「换 LLM」不算）。
- 三个创新点：① 几何接地的 3D 工具库 ② 3D Scene Graph 作空间中间表示 ③ 面向 3D Tool Calling 的 QLoRA。

**技术栈**（全 Windows 原生）：检测 `IDEA-Research/grounding-dino-tiny`｜分割 `facebook/sam2.1-hiera-base-plus`
（均 Apache-2.0）｜3D `lpiccinelli/unidepth-v2-vits14`（**CC BY-NC 4.0**）｜LLM `qwen3.5:4b`（可选）
｜执行器 `multiprocessing`+timeout（替代 SIGALRM）｜Demo Rerun → Three.js+FastAPI+WebSocket。
**课程/学术可用，不可商用，报告须注明。**

**检测器接口三处关键**：prompt 必须小写句点紧跟标签（`"box. door."`）；返回**绝对像素 xyxy**（非归一化 cxcywh）；
后处理关键字随版本变过（`box_threshold`→`threshold`）→ 用 `inspect.signature` 读真实签名。
`grounding-dino-tiny` **就是** VADAR 用的 SwinT-OGC 的 transformers 移植版（换加载方式，不是换模型）。

**SAM2 两处 API 陷阱**：`Sam2Processor.__call__` 第一个参数是 `images=` 而非 `image=`（报错信息指向错误参数，极难排查）；
`post_process_masks` **没有** `reshaped_input_sizes` 参数，按位置传第三个会被当成 `mask_threshold` → **静默改变二值化阈值**。
一律关键字传参 + 自省签名。

## 5. VADAR 已核实的 bug / 事实（报告要用）

1. `SignatureAgent.dataset` 恒为 "clevr"（`agents.py:54`+`:42`）→ Omni3D 用了 CLEVR prompt
2. `Get2DObjectSize.execute_pts`（`:550`）调用未定义的 `self._get_bbox`
3. `Generator` 出错 `time.sleep(60)` 无限重试（`engine_utils.py:94-96`）→ 静默卡死
4. 方法名正则 `def (\w+)\s*\(.*\):` 要求字面量 `):` → 模型加 `-> float` 注解即 AttributeError（实测）
5. `<answer>` 用 `re.findall(...)[0]`，模型不吐标签即 IndexError（实测）
6. `Generator.__init__` 构造即 `open(api.key)` 必 FileNotFoundError、无 `base_url`
7. 四类标签契约：`<docstring>`/`<signature>`（`agents.py:82-83`）、`<implementation>`（`:298`）、
   `<program>`（`:757`/`engine.py:344`，**返回 list 不是 [0]**）、`<answer>`（`:354`，`[0]` 直接崩）
8. **`--num-api-questions` 默认 10，`evaluate.py:42` `random.sample` 抽题 → API 每次运行都不同 = 不可复现的根因**
9. 真正被评分的只有 `final_result`（`engine.py:292-303`）；**缺失即 `""` 静默算错**
10. README 写 `image`: PIL Image 是错的，真实读 `question["image_filename"]`（证明我们读代码而非抄文档）
11. 论文 40.4 是 gpt-4o 成绩，**不可复现也不能直接比** → 只作文献引用加脚注；
    消融基线改「VADAR 原始流水线 + 强开源模型」

**LLM 后端（2026-09-15 实测）**：8 个国产/中转端点全部可用（401 = 已应答）：deepseek / 阿里百炼 / 智谱 /
火山 ark / Moonshot / 硅基流动 / 腾讯混元 / OpenRouter；**只有 `api.openai.com` 网络层超时**。
硬条件：主模型必须多模态（`vqa()` 内联 base64）。价格高峰/空闲差一倍（高峰 = 北京 9–12、14–18 点）
→ **全量实验放空闲时段账单减半**。需替换 **4 个模块级绑定**：
`engine.engine_utils` 定义处、`engine.predefined_modules:23` 星号导入、`engine.engine:20-25`、`agents.agents:19-26`。

**模型选型不是硬依赖**：L1 技术强制 = 「动作空间是 Python」（换模型代价 0）；L2 项目派生 = 能看图 /
8GB 可推理 / 能本地 QLoRA / 国产；L3 = 改环境变量。**「同族尺寸阶梯」把「默认选 Qwen」从偏好升级为方法学要求**
（跨族会混入 tokenizer / chat template 混杂因子）。架构上三个角色拆开比选型更重要：
① 程序合成（纯文本即可）② 视觉语义（1–2B 小 VLM）③ 空间几何（**不需要 LLM**）。

## 6. 三角色接口契约（Phase 1 核心设计）

| 角色 | 签名 | 关键约束 |
|---|---|---|
| ① 程序合成 | `synthesize(question, tool_docs, scene_hint, memory, feedback)` | **主路径 1 次调用**；AST 四项检查；**`scene_hint` 不含坐标** |
| ② 视觉语义 | `describe(image, region, attrs=Literal[...], candidates)` | **签名里没有任何空间参数** |
| ③ 几何 | 内层 `relations.py` 纯函数 / 外层 `tools/spatial.py` 吃 id | **永不调用 LLM** |

**三处「签名层面堵死」**（可直接进答辩稿）：`scene_hint` 只给 label 与计数（把「坐标只能来自工具返回值」
从提示词要求升级为**信息约束**）；`describe(attrs=Literal["color","material","texture","state","shape"])`
（**空间幻觉在类型层面写不出来**）；`submit(answer, target_ids, evidence≥1)` 取代 VADAR 的 `final_result` 魔法变量。

**主次裁决**：主路径 = **单轮程序合成**（1 次 LLM 调用），多轮 tool-calling 降为消融臂 E′。
理由：空间问题本质是「组合 + 算术 + 聚合」（JSON tool call 表达不了 `argmin`）。两者**只换循环层**，消融干净。

**信封** `ToolResult{ok, value, evidence, error, meta}`；6 个错误码枚举（`NOT_IN_SCENE` 是**幻觉捕获点** /
`NOT_FOUND` / `AMBIGUOUS` / `DEGENERATE` / `LOW_CONFIDENCE` / `CAPABILITY_DISABLED` —— 最后这个让
「关能力」成为**接口开关而非 prompt 变体**，消融才可复现）。

**工程裁决**：失败必须带 `ToolError`（「静默失败」在类型层面构造不出来）；恢复动作也枚举化随 `to_dict()` 输出；
**参数值域错误必须冒泡**（归到「程序」类失败）；`find_nearest` 必须排除 anchor 自身。
错误提示必须具体到「下一步调什么」（只说「包围盒缺失」模型会重试同一条路）。

## 7. 答辩口径（三个必被问到的质疑）

- **Q1「2D 照片也算 3D 视觉？」** 判据不在传感器，在工作空间。**2D 是传感器的形式，3D 是系统的表示；
  VADAR 拿到同一个点云却只取了 z 列。** 反证：它的 3D 尺寸公式没有焦距，量纲不成立。
- **Q2「几何全能算，Agent 干什么？」** 几何确定，但**从自然语言到几何查询的映射不确定**——
  指代消解 / 计划分解 / **组合与聚合** / 错误恢复。③ 正是选「Python 程序」而非 JSON 的根本理由。
  Agent **不判断空间关系、不输出坐标、不做算术**。
- **Q3「输出会不会太简单？」** 诚实答：「若只输出一个答案，确实单薄。」
  加厚方向已全部落地进文档（两类输出、L5 场景级输出、加分项）。
  > 分量不在输出花哨，而在**定量消融表（12 指标 × 9 个实验臂）+ 自建数据集 + 本地 QLoRA**。

**L5 场景级输出**（`tools/scene_report.py`）：`describe_scene` / `summarize_scene`（L5 中唯一允许走 LLM）/
`answer_with_evidence` / `diagnose_failure` / `counterfactual`（纯图操作，零 GPU）。
落点是 **Phase 5 不是 Phase 11**（只依赖已算好的质心与关系，最便宜的一层）；
Phase 10 出**两张表**（问答表 + 场景理解表）用于归因「瓶颈在语言还是视觉」，
且表 B 不需 GT 问答对 → **可用自己拍的照片扩容样本**。

## 8. 本机环境金律（每次都踩，务必先读）

| 现象 | 对策 |
|---|---|
| **单条命令约 121 秒被杀**（前台后台一视同仁，日志无 ERROR） | 每条命令 ≤110 s；安装/下载一律拆片 |
| pip 下大文件静默卡死（2.5 GB 轮子 18 min 0 字节） | 大文件用 **`curl -C -`**，别交给 pip |
| **`.ps1` 报「命令未找到」**：`MinBytes = 100B` | PowerShell **没有 `B` 数值后缀**（只有 KB/MB/GB/TB）；小文件阈值写**纯字节数** |
| `.ps1` **并非"无法执行"（旧结论已推翻）** | `powershell -NoProfile -ExecutionPolicy Bypass -File x.ps1` 可正常执行，exit code 与 stderr 都读得到 |
| `curl -C -` 对已完整文件返回 **http=416** | 加分支识别，否则白跑满重试次数 |
| **PowerShell stdout 不回传 Agent**；bash 不可用 | 一律「命令写文件 → Read 读文件」。**更好的办法是让 Python 脚本自己写报告文件**（UTF-8 由 Python 控制，绕开整条控制台编码链）；实在要抓 stdout 就先设 `[Console]::OutputEncoding=UTF8` + `PYTHONIOENCODING=utf-8` |
| **`*>` 让成功命令返回 exit=1** | PowerShell 把子进程 stderr（timm/xformers warning）当 NativeCommandError。判断成败要看脚本自己写的产物，不要只看 exit code |
| **CUDA 计时不用 `synchronize` 会差一个量级** | 实测同模型同步 47 ms / 不同步 28 ms，且不同步时「第二条路径」总显得更快 —— 那是 kernel 排队顺序造出的假结论。测 GPU 一律 `torch.cuda.synchronize()` 夹住 + 先跑一次丢弃预热 |
| `huggingface.co` 直连超时 | `HF_ENDPOINT=https://hf-mirror.com` + **`HF_HUB_DISABLE_XET=1`**（xet 仅 0.5 MB/s） |
| HF `snapshot_download` 下两份等价权重 | 加 `allow_patterns=["config.json","*.safetensors"]` |
| **改完文档 HTML 像只渲染了一半** | Markdown 里字面量尖括号（写「i 小于 j」时用 `<j`）会被当**未闭合标签吞掉文档剩余部分** —— 症状是正文中途断掉、后面章节与附录整块消失。重建后**必须 grep 一次末尾章节标题** |
| **同一文件多处编辑不能并发发** | 同一条消息里对同一文件发多个 Edit 会互相覆盖（第一个改动被吃掉）→ **同文件多处编辑一律串行发送** |

**依赖裁剪**：**`wandb` 不能跳过**（`unidepth/utils/visualization.py:11` 是裸 `import wandb`，导入即 ModuleNotFoundError）
→ 装上而不是改 vendor 源码。可跳过：`triton`（无 Windows 轮子）、`xformers`（4 处 import 全在 try/except 内）、
`torchaudio` / `gradio` / `tables`。
**torch 轮子 ABI 锁死在 Python 版本上，跨环境拷贝无效。**
**本机事实**：C 盘 21.8 GB / D 盘 381 GB（工作盘）；WSL 确认没装；Ryzen 9 7945HX；RTX 4060 Laptop 8188 MiB。

## 9. 阶段路线

Phase 0 环境 ✅ → 1b 骨架 ✅ → 1c 感知层/builder ✅ → 1 跑通 VADAR 原版（对照臂 A，只差一个便宜 key）
→ 2 吃透架构 ✅ → 3 接开源 LLM → 4 显存工程 → 5 3D 工具库 + L5 → 6 Scene Graph → 7 自研 Agent
→ 8 数据集合成 → 9 QLoRA → 10 评估 → 11 Viewer → 12 完整实验 → 13 答辩 Demo

**唯一剩下的真问题**：4B 级模型能不能守住「给定固定工具文档 → 生成可执行、语法正确、调用合法工具、结果正确」？
零成本测法：固定工具文档 + 20 道空间题 + **AST 静态检查**四项（能否 `ast.parse`、函数名是否在白名单、
参数名是否存在、是否产出 `final_result`）—— 不需真执行 / torch / 联网。
- 能 → 正常推进；不能 → **顺序反过来：先数据集合成 + QLoRA，再接模型**（微调成为可行性前提）